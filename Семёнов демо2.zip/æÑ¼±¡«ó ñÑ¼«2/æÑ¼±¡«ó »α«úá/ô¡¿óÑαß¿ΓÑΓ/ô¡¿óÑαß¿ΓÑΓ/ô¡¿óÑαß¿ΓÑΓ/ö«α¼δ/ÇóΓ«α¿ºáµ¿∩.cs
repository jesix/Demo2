﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Университет
{
    public partial class Авторизция : Form
    {
        public Авторизция()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) // кнопка входа
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e) // переход на главное меню студента
        {
            Меню меню = new Меню();
            меню.Show();
            Hide();
        }

        private void button3_Click(object sender, EventArgs e) // переход на главное меню преподавателя 
        {
            МенюПрепода менюПрепода = new МенюПрепода();
            менюПрепода.Show();
            Hide();
        }

        private void button2_Click(object sender, EventArgs e) // переход на главное меню администратора
        {
            МенюАдмина менюАдмина = new МенюАдмина();
            менюАдмина.Show();
            Hide();
        }
    }
}
